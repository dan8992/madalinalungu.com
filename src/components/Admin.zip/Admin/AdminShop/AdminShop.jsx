import React from 'react';
import AdminBurgerMenu from '../AdminBurgerMenu/AdminBurgerMenu';

const AdminShop = () => {
  return (
    <div>
      <AdminBurgerMenu />
    </div>
  )
}

export default AdminShop;
