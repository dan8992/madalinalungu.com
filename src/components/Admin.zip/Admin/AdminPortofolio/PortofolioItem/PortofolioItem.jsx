import React from 'react';
import './PortofolioItem.css';

const PortofolioItem = () => {
  return (
    <div>
      CARD
    </div>
  )
}

export default PortofolioItem;
