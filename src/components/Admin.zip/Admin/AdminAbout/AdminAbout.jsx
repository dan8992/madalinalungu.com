import React from 'react';
import AdminBurgerMenu from '../AdminBurgerMenu/AdminBurgerMenu';

const AdminAbout = () => {
  return (
    <div>
      <AdminBurgerMenu />
    </div>
  )
}

export default AdminAbout;
